import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.util.Log;
import android.widget.Button;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;


public class Utilities {
    public static boolean isDirectoryExists(String directoryPath) {
        File directory = new File(directoryPath);
        return directory.exists() && directory.isDirectory();
    }
    
    public static boolean isFileExists(String filePath) {
        File file = new File(filePath);
        return file.exists() && file.isFile();
    }

    public static String getPrivateFilesDirectory(Context context) {
        return context.getFilesDir().getAbsolutePath();
    }
    
    
    public static void showAlertDialog(Context context, String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // Perform any necessary actions when the user clicks the positive button
                }
            })
            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // Perform any necessary actions when the user clicks the negative button
                }
            });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
    
    public static boolean copyAssetFile(Context context, String assetFileName, String destinationFilePath) {
        AssetManager assetManager = context.getAssets();
        InputStream inputStream = null;
        OutputStream outputStream = null;
        boolean success = false;
        
        try {
            inputStream = assetManager.open(assetFileName);
            outputStream = new FileOutputStream(destinationFilePath);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            success = true;
        } catch (IOException e) {
            Log.e("Utilities", "Failed to copy asset file: " + assetFileName, e);
           // return false;
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (outputStream != null) {
                    outputStream.close();
                }
            } catch (IOException e) {
                Log.e("Utilities", "Error closing streams", e);
            }
        }
        return success;
    }

    public static boolean addExecutablePermission(String filePath) {
        try {
            String command = "chmod -R 755 " + filePath;
            Process process = Runtime.getRuntime().exec(command);
            int exitValue = process.waitFor();
            return exitValue == 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean isFileExecutable(String filePath) {
        File file = new File(filePath);
        return file.canExecute();
    }

    public static boolean createDirectory(String directoryPath) {
        File directory = new File(directoryPath);
        return directory.mkdirs();
    }

    public interface CommandResultListener {
        void onCommandOutput(String output);
        void onCommandComplete(int exitValue);
        void onCommandFailed(IOException e);
    }

    public static void runBinaryProgram(final String[] command, final CommandResultListener listener) {
        new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Process process = Runtime.getRuntime().exec(command);

                        // Read the output in real-time
                        InputStream inputStream = process.getInputStream();
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                        String line;
                        while ((line = reader.readLine()) != null) {
                            listener.onCommandOutput(line);
                        }

                        // Wait for the process to finish
                        int exitValue = process.waitFor();
                        listener.onCommandComplete(exitValue);
                    } catch (IOException e) {
                        listener.onCommandFailed(e);
                    } catch (InterruptedException e) {
                        // Restore interrupted status
                        Thread.currentThread().interrupt();
                    }
                }
            }).start();
    }
    
    
    public interface AlertDialogListener {
        void onButtonClick(int buttonIndex);
    }

    public static void showAlertDialog(Context context, String title, String message, String[] buttonLabels, final AlertDialogListener listener, boolean cancelable) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title)
            .setCancelable(cancelable)
            .setMessage(message);

        builder.setPositiveButton(buttonLabels[0], new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (listener != null) {
                        listener.onButtonClick(0);
                    }
                }
            });

        for (int i = 1; i < buttonLabels.length; i++) {
            final int buttonIndex = i;
            builder.setNeutralButton(buttonLabels[i], new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (listener != null) {
                            listener.onButtonClick(buttonIndex);
                        }
                    }
                });
        }

        AlertDialog dialog = builder.create();
        dialog.show();

        // Access the dynamically added buttons if needed
        for (int i = 0; i < buttonLabels.length; i++) {
            Button button = dialog.getButton(i);
            // Perform any necessary customization or action with the button
        }
    }
    
}
