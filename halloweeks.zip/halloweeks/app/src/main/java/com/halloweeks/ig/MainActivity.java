package com.halloweeks.ig;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import Utilities;

public class MainActivity extends Activity {
    private TextView outputTextView;
    private Process process;
    private ScrollView scrollView;
	
	private List<String> lines;
    private static final int MAX_LINES = 30;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        outputTextView = findViewById(R.id.outputTextView);
		outputTextView.setText("");
		
        outputTextView.setMovementMethod(new ScrollingMovementMethod());
        
		lines = new ArrayList<>();
		
        scrollView = findViewById(R.id.scrollView);
        
		final String file = Utilities.getPrivateFilesDirectory(MainActivity.this) + "/main";
        
		if (!Utilities.copyAssetFile(MainActivity.this, "main", file)) {
            Utilities.showAlertDialog(MainActivity.this, "Error", "Failed to copying binary core file into " + Utilities.getPrivateFilesDirectory(MainActivity.this) + "/");
        }
		
		if (!Utilities.addExecutablePermission(file)) {
            Utilities.showAlertDialog(MainActivity.this, "Error", "Failed to add executable permission to core file");
        }
		
		
		
		new Thread(new Runnable() {
				@Override
				public void run() {
					Process process = null;
					BufferedReader reader = null;

					try {
						// Command to execute
						process = Runtime.getRuntime().exec(new String[]{file, "com.halloweeks.ig"}); // Replace with your command

						// Create a BufferedReader to read the output
						reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						// final StringBuilder updatedText = new StringBuilder();
						String line;

						// Read output from the command continuously
						while ((line = reader.readLine()) != null) {
							// Accumulate the output
							// output.append(line).append("\n");

							// Update the UI on the main thread for each line read
							final String currentLine = line; // Store in final variable for UI update
							
							runOnUiThread(new Runnable() {
									@Override
									public void run() {
										lines.add(currentLine);
										
										if (lines.size() > MAX_LINES) {
											lines.remove(0); // Remove the oldest line
										}
										
										StringBuilder updatedText = new StringBuilder();
										
										for (String line : lines) {
											updatedText.append(line).append("\n");
										}
										outputTextView.setText(updatedText.toString());
										
										// outputTextView.append(currentLine + "\n");
										scrollView.fullScroll(View.FOCUS_DOWN);
									}
								});
						}

						// Wait for the process to finish (if needed for cleanup)
						final int exitCode = process.waitFor();

						// Optionally, you can update the UI once the process finishes
						runOnUiThread(new Runnable() {
								@Override
								public void run() {
									outputTextView.append("End\nExit code: " + exitCode);
								}
							});

					} catch (IOException | InterruptedException e) {
						
					} finally {
						// Clean up resources
						if (reader != null) {
							try {
								reader.close();
							} catch (IOException e) {
								e.printStackTrace(); // Handle or log this exception as necessary
							}
						}
						if (process != null) {
							process.destroy(); // Ensure the process is terminated
						}
					}
				}
			}).start();
		
		
		
		
		/*
		// Start a new thread to execute the command
        new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						// Command to execute
						process = Runtime.getRuntime().exec(new String[]{file, "com.halloweeks.ig"}); // Replace with your command
						BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						final StringBuilder output = new StringBuilder();
						String line;
						
						outputTextView.setText("Start\n");

						while ((line = reader.readLine()) != null) {
							output.append(line).append("\n");
							outputTextView.append(output.toString());
						}

						// Wait for the process to finish
						final int exitCode = process.waitFor();
						
						outputTextView.setText("End\n");
						
						// Update the UI with the output (run on UI thread)
						runOnUiThread(new Runnable() {
								@Override
								public void run() {
									outputTextView.setText(output.toString() + "\nExit code: " + exitCode);
								}
							});

					} catch (IOException | InterruptedException e) {
						Utilities.showAlertDialog(MainActivity.this, "error", e.getMessage());
						// e.printStackTrace();
					}
				}
			}).start();
        */
        
    }
	
	/*
    private void runCommand(final String[] command) {
        try {
            // Use a shell to execute the command
			
            // Thread to read output from the command
            Thread outputThread = new Thread(new OutputReader(process.getInputStream()));
            outputThread.start();

            // Thread to read error stream
            Thread errorThread = new Thread(new OutputReader(process.getErrorStream()));
            errorThread.start();

        } catch (IOException e) {
			Utilities.showAlertDialog(MainActivity.this, "Error", e.getMessage());
            e.printStackTrace();
        }
    }

    private class OutputReader implements Runnable {
        private BufferedReader reader;

        public OutputReader(InputStream inputStream) {
            this.reader = new BufferedReader(new InputStreamReader(inputStream));
        }

        @Override
        public void run() {
            try {
                String line;
                StringBuilder output = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                    updateOutput(output.toString());
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    reader.close(); // Close the reader when done
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    */
    
    

    @Override
    protected void onDestroy() {
        super.onDestroy();
		
		if (process != null) {
            process.destroy(); // Stop the running command
            process = null; // Clean up the reference
        }
    }
}
